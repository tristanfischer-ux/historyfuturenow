---
title: 'Crisis: Or An Explanation On The Origins Of The Decline Of The West'
url: >-
  https://www.historyfuturenow.com/part-2-global-balance-of-power/crisis-or-an-explanation-on-the-origins-of-the-decline-of-the-west
image: "/images/crisis-decline.png"
type: article
part: Global Balance of Power
slug: crisis-or-an-explanation-on-the-origins-of-the-decline-of-the-west
excerpt: >-
  Christopher Marlowe’s play Doctor Faustus was written in 1592 and was based on
  an earlier German work about Dr Faustus, a talented German scholar at
  Wittenburg University who was frustrated by the limits of human knowledge.
  Feeling that he understood everything humanly possible, he made a bargain with
  Lucifer that for 24 years he would have access to knowledge that had hereto
  been hidden from humanity. In return, he would give his soul to the devil. The
  devil lived up to his side of the bargain and, 24 years later, comes to claim
  Faustus’ soul. Faustus, realising his mistake, is horrified and begs for mercy
  from God and the devil. But it is too late and he is dragged off. His friends
  later find his body, torn to pieces.
signal: ''
---
# Crisis: Or An Explanation On The Origins Of The Decline Of The West

Christopher Marlowe’s play Doctor Faustus was written in 1592 and was based on an earlier German work about Dr Faustus, a talented German scholar at Wittenburg University who was frustrated by the limits of human knowledge.  Feeling that he understood everything humanly possible, he made a bargain with Lucifer that for 24 years he would have access to knowledge that had hereto been hidden from humanity.  In return, he would give his soul to the devil.  The devil lived up to his side of the bargain and, 24 years later, comes to claim Faustus’ soul.  Faustus, realising his mistake, is horrified and begs for mercy from God and the devil. But it is too late and he is dragged off.  His friends later find his body, torn to pieces.

In 1992 the West signed its own Faustian bargain.  Not exactly with the devil, but for a promise of unparalleled wealth and a monopoly of power over the entire world.  In return for this bargain we would leave our economies and societies in ruin and usher in the possible end of the West’s dominance over the world that it had enjoyed since the 1500s.

History Future Now looks at what happened.  This article covers a lot of ground – 500 years of history ranging from the Age of Discovery to the Opium Wars; a geographical reach over the entire globe, from Edo to Constantinople and Beijing to Washington; economic thought, from mercantilism to free trade; regulation and deregulation; and the impact of the financial services sector on jobs and our economies.  It even includes an action list of what we need to do to escape from this Faustian bargain.

While there is never a real beginning to a story in history – there is always a possible prequel – we first need to go back to the traumatic events of 1917 and then look forward all the way to 2013 and beyond.

The Rise and Fall of Communism

The rise of Communism came about, like many things in history, as a result of a long series of unintended consequences.

In 1917 the German government arranged for a special sealed train to take Vladimir Lenin from his exile in Switzerland, via Germany, Sweden and Finland to Russia in return for a promise to pull Russia out of the war once the Tsar had been toppled.  Lenin won the revolution, kept his side of the bargain, and Russia pulled out of the Great War, allowing Germany to focus her war efforts on the Western Front. Despite the rhetoric, relations between Russia and Germany remained good all the way up to Hitler’s invasion of the Soviet Union in June 1941.  As German tanks crossed the border into the Ukraine, Soviet freight trains, carrying raw materials for German factories, crossed the border in the other direction.  The Allies, who generally loathed and feared Communism, found themselves supporting Stalin for the next four years, until the end of the Second World War ushered in the Cold War.

The Second World War created a huge upheaval in the global balance of power. Western Europe, which had been the dominant force in the globe, with colonial territories everywhere, shriveled economically, politically and militarily.  Britain lost Canada, Australia, New Zealand and India, plus her African territories.  France and Italy also retrenched. The United States, which had been an isolationist power since the days of President Jefferson, found itself in the lucky position of being the only major country left undamaged in the West.  Not only financially secure but with an economy that had been supercharged by the war, and with a military-industrial complex that rapidly filled in the vacuum created by the loss of Western European hegemony.  The death of millions of men and the general destruction of European countries' infrastructure led to a post-war continuation of mobilisation of economies, with levels of government intervention and control which would have been unthinkable prior to 1939. This general move towards a semi-social state was only outdone by the Soviet Union, whose command and control economy enabled it to produce war materiel in enormous quantities, to the detriment of its overall economy.

From 1945 to 1991 the world became bi-polar with the West, aligned around the United States, facing off against the Eastern block, aligned around the Soviet Union.  The Third World, those that were officially unaligned in this struggle, was either ignored or became the hosts to proxy battles between the two great superpowers.  But by 1989 tensions within the Soviet Union meant that its dominance over its satellite states ended.  Gorbachev pulled out of the long war in Afghanistan in March of that year. By November most of the former Soviet block had gone their own way, with new independent  leaders in Poland, Hungary and Romania.  The Berlin Wall fell which led to the eventual reunification of most of Germany. The Soviet Union fractured irrevocably and on Christmas Day 1991 the Soviet flag was pulled down for the last time over the Kremlin.

Why did Communism Fail and Free Market Capitalism succeed?  The search for a reason.

The success of the US over its former wartime ally then Cold War enemy, the Soviet Union, seems inevitable in hindsight: the Soviet Union, for all its posturing and arsenal of weapons was not as powerful as it had originally appeared.

The problem with the US victory over Communism, however, was that it reinforced a set of American myths.  This dillusion meant that the US, and by proxy the West, learned the wrong lessons about why they had been victorious.  An inevitable search began to contrast the differences between the Soviet and Western system.  There was a neat logic: if the Soviet Union did one thing and the US the opposite then, since the US had won, the US way of doing things had to be superior.

The American Communist party had argued with Stalin in the 1920s that America was “exceptional” in the history of the world and fell outside Marx’s laws of history “thanks to its natural resources, industrial capacity and absence of rigid class distinctions”.

This view reinforced the concept of  "American exceptionalism” that had existed since Alexis de Tocquville, the famous on-the-ground observer of the American Revolution, wrote in his 1840 book ‘Democracy in America’ that ‘The position of the Americans is therefore quite exceptional and it may be believed that no other democratic people will ever be placed in a similar one.’

Indeed, the United States of America has been exceptionally lucky throughout history.  At the time of the American Revolution the 13 British colonies were just part of a collection of European settlements in North America. Spain, with its possessions in the south, and France, to the west, claimed jurisidiction over the bulk of North and Central America.

Then, out of the blue, Napoleon Bonapart’s shortage of cash for his European wars led him to sell France’s continental territory of Louisiana to President Jefferson in 1803.  This fortuitous acquisition doubled the size of the US. Later territorial conquests over Spanish Mexico, in the run up to the US Civil War, expanded the available land.  The post Civil War incorporation of Territories in the mid-West into the United States continued to ensure that US citizens had the one thing that most other people across the world lacked.   American people owned huge quantities of virgin land and natural resources for expansion.  While Old World governments lived cheek by jowl alongside rivals countries with whom relationships veered, the US government and its people had an almost free hand across the continent.

Unfettered access to land and resources, and freedom helped to make America ‘exceptional’.  Yet by the late 1890s the Trusts, established by Rockefeller, Morgan and Carnegie, had started to use this unfettered freedom to establish powerful business monopolies that were for the benefit of the few not the many.  These powers were used to abuse the democratic system,  in the 1896 US presidential election William McKinley was effectively bought.  For the next five years President McKinley protected his paymasters, until he was assassinated and his Vice President, the fiery, progressive, Theodore Roosevelt became President.  President Roosevelt instigated reforms that bust the trusts and set up a governing ideology that was adopted by both Republicans and Democrats.

And yet the mythology of the great frontier, a place where citizens were in charge of their own destiny and hard work was all that was needed to create wealth and prosperity, continued.  By the late 1920s the US was on a roll.  Low interest rates, set by the newly created Federal Reserve Bank, enabled a huge speculative bubble to emerge in the stock market and in property.

Everybody felt wealthy.  A dour Austrian economist, Frederik Hayek, warned about the possible impact of lax monetary policy in late 1929.  A few weeks later the 1929 Wall Street crash started, which left the US in deep economic turmoil, until a flood of government expenditure, thanks to the Second World War, pulled the US out of the Great Depression.

The post war US experience was radically different to that of the citizens of Europe.  For Europeans, life was harsh.  Government became key to survival.  It helped to rebuild destroyed roads, bridges and infrastructure.  It looked after the widowed, the wounded and the orphaned. It set up institutions like the European Coal and Steel Community in 1950 to ensure that interdependence among leading European nations would make war between Europeans impossible in the future.

In contrast, for Americans the post war period was a boom time.

Government intervention in the economy was still many times larger than it had been prior to the Second World War.  The US continued to maintain a large military presence – which President Eisenhower warned about as the military-industrial complex.  But the private sector boomed as well, with US firms taking advantage of the destruction of European businesses to expand into markets that had hereto been closed to them.  Expansion overseas was also matched by an expansion of infrastructure, such as the highway system, in the US itself.

By the 1970s Europe had started to recover from the Second World War.  European and Japanese businesses, which had been wiped out by the war, started to compete again on the international stage.  The US euphoria of the 1960s, culminating in the July 1969 landing of Neil Armstrong and Buzz Aldrin on the Moon, was replaced by the general feeling of malaise of the 1970s.  President Nixon resigned in disgrace in 1974, replaced by President Ford and then the do-gooding, peanut farming, Jimmy Carter, who left America humiliated over the Iran hostage crisis of 1979-1981.

In January 1981 President Reagan promised a new dawn for America.  Handsome and articulate, he embodied the western myth of the great frontiersman wherein all people had to do was work hard to get ahead in life.  Reagan’s view that government was the problem, not the solution, resonated with the people.  Despite this avowal Reagan presided over a massive increase in government expenditure to fund a military build up against the Soviet Union, now dubbed the “Evil Empire”.

And so when the Soviet Union collapsed on Christmas Day 1991, the lesson that everybody learned was that big government socialism and communism had failed. Communists had literally pulled down the flag over the Kremlin.  In contrast, the lesson that free, open, markets had won was obvious to all.

1992 ushered in a new form of global dominance.  America became a hyper power.  It was socially, culturally, economically and militarily the most powerful country in the world.  More powerful than any country had been in the history of mankind.

Socialist leaning political parties across Europe and the Democratic Party in the US found themselves on the back foot.  To compete against this new truth, that the free market was victorious, they rapidly changed their own policies.  In the US, Reagan’s apprentice, Bush, lost out against Clinton with his 'third way' political views.  In the UK, Thatcher’s successor, Major, lost out against Blair who some consider to be Thatcher's natural heir despite his different part allegiance.  Blair's Britain mimicked many of Clinton’s policies.  Free market ideology ruled, unchallenged.

And yet, a mere 21 years later, in 2013, the West appears weaker than at any time since the Ottoman Turks conquered Constantinople in 1453.

What happened?

Success led to learning the wrong lesson

The problem for the West in its victory over Communism was that the lesson that it learned was faulty.  The belief that free, open, markets are good and that communism was bad was only partially true, some of the time. And as with most things in life, timing is everything.

After the Second World War, US companies were able to expand into territories that had previously been dominated by European businesses and governments.  For them free markets were fantastic: they had products, goods and services that people wanted and all of their competitors had literally been blown to pieces.

Japan quickly realised that this free-for-all was all very well for US companies but was terrible for Japanese companies who were struggling to compete in their home market, let alone trying to expand overseas. Japan consequently slapped on trade tariffs, and legislated local content and ownership rules, much to the chagrin of US companies.  Under the resultant protectionist shield Japanese companies developed innovative products for their home market and by the 1980s were able to sell their better products at lower prices to the Americans and to Europeans.

The 1990s ushered in a repeat of the US’s experience after the Second World War. The collapse of the Soviet Union not only opened up the entire Soviet block to Western companies, but also gave access to the rest of the hereto ignored Third World of non-aligned countries and former colonial territories.

US and European consultants descended on credulous government bureaucrats all over the world and persuaded them to open up their countries and liberalise as fast as possible through “shock therapy” and mass privatisations.  Trade barriers came down and huge state owned companies were snapped up by local kleptocrats, people who happened to have the right jobs at the right time.  By 1994 Coca Cola and McDonalds outlets could be found over most of the former Soviet Union and beyond, symbols of American culture and business prowess.

Throughout most of the 1990s the West experienced a peacetime dividend: even the blip of the first Gulf War merely reinforced the West’s sense of superiority as US equipped Allied forces obliterated Soviet equipped Iraqi forces.  Technology, which had been relatively stagnant since the mid 1960s, seemed to speed up again with the advent of personal computers and mobile phones.  The concept of the ‘service sector’ took root, with financial sector deregulation seemingly able to create huge profits without the sweat and toil of manufacturing and filthy extraction of raw materials.

And so by the time President William Jefferson Clinton stepped down on 20th January 2001 the West had gone through a thirty-year epic drama, divided into three acts almost a decade long apiece.  The first act, showed the West in decline, a victim of over regulation and big government under Carter, amongst others.  The second act was the re-establishment of power of the individual and free markets under Reagan and Thatcher opposed to the tyranny of big government and communism.  The third act showed the West taking the prize, with Communism crushed and Western values of freedom and open markets under the centrist governments of Clinton and Blair.

Thirty years is a big chunk of a human’s lifespan.  If you are less than 40 years old today this 30-year period represents almost everything that you know.  If you are sixty years old this epic drama represents your entire working life.

But, what if everything you think you know to be true is actually wrong?

What if the lesson about the march of free markets from 1971 to 2001 is the wrong lesson to have learned?

Unfortunately, it was the wrong lesson.  The West’s rise predated Karl Marx by 400 years and its success had nothing to do with free markets.  To explain why we first need to go back even further in time, to 1453.

The defeat of Constantinople and the rise of Western mercantilism

The year 1453 has to be a front-runner for the most important date in the history of the world.  This year, which represented a defeat for Christendom and a victory for Islam, is the pivot point which turned Western Europe from being at the furthest edge of Eurasia to being at the center of a Western dominated Atlantic Ocean.  A center crisscrossed by trading routes between the Americas and Europe which would expand to control Africa, Australasia and Asia itself.

Trade between China and Europe had travelled along the Silk Road since the time of the Romans.  Asia had two major, highly portable, commodities that the West desired: silk, produced through a secret process in China, and spices from India and South East Asia.  China, in return, wanted only two things: silver and gold.

To get to Asia Europeans needed to cross through the eastern Mediterranean. By 1450 all of this territory was under Muslim rule.  Egypt, Palestine and Syria were under the control of the Malmuks and the Karmanid Empire that ruled south east Turkey.  The Ottoman Empire controlled most of western and northern Turkey and the southeastern edge of Europe.  Byzantium had shriveled to a rump state around the city of Constantinople, with much of southern Greece also under their control.

Nevertheless, the European traders – mainly from Genoa and Venice – continued to trade with Asia, via Muslim middlemen.  Mehmed II succeeded his father as sultan of the Ottomans in 1451 and, although only 19, immediately went about preparing to capture Constantinople.  He was successful and in May 1453 took over the city.  He cut off the Silk Road from the West in the process.

The next forty years marked a period of extensive period of exploration by European traders who were frantic to find an alternative route to Asia, bypassing the Muslim blockade. The traders and country that controlled this trade would become very wealthy.  The Portuguese had already mastered much of the long distance navigation required to find this route: they had been exploring the west coast of Africa in search of gold and slaves.

In 1455 Pope Nicholas V issued a papal bull in favour of King Alfonso V of Portugal, which gave the Portuguese the legal right to a monopoly of trade in Africa and Asia.  All lands that were settled and all peoples discovered were to become the property of the Portuguese.  Vasco da Gama found the sea route to India in 1498 and Christopher Columbus discovered the Americas in 1492, prompting another papal bull in 1493 (by the Spanish Pope Alexander VI) granting Spain all lands to the west and south of a pole to pole line 100 leagues west and south of any of the islands of the Azores or the Cape Verde Islands.  Since Brazil, as yet undiscovered, jutted out so far to the east it is for this reason that Brazil became a Portuguese colony in an otherwise Spanish continent.

This process of granting monopolies was to form the core of a new philosophy for dealing with trade and foreign affairs, called mercantilism. It was this mercantilist philosophy that was to fuel the rise of the West.

Mercantilism’s role in the rise of the West

Before the Industrial Revolution decoupled the link between labour and output it was believed that a country’s wealth, and thus its ability to arm itself and project power, was seen as a zero sum game.  If one country had wealth it meant that another country did not.

Early mercantilist philosophy was driven by the empirical experience of traders who saw that if one country, such as Spain and Portugal, had control over the wealth of the Americas, Africa or Asia, they would be wealthier and thus more powerful.  This was obvious to any observer at the time.  The discovery of a mountain made out of silver in Peru at Potosí resulted in Spain becoming incredibly wealthy.   Spain was then able to buy not only luxuries from China, who loved silver above all thing, but also to gain political, religious and economic dominance over Europe.

A driver for Elizabethan England was to find a way to combat an increasingly dominant Spain. Elizabeth and her government adopted similar restrictive trade practices.  They established English colonies in North America and licensed private English shipping to harass and steal from Spanish bullion ships as part of that strategy.  In 1549 a pamphlet appeared claiming that “We must always take heed that we buy no more from strangers than we sell them, for so would we impoverish ourselves and enrich them.”

By the 1620s writers such as Thomas Mun, who was a director of the East India Company, were expanding the philosophy to recommend that England increase its wealth by frugal domestic consumption, and a reduction of imports by better exploiting England’s own natural resources. Furthermore to lower export duties to encourage sales overseas.  Later mercantilist writers would add that imports should be restricted if the goods could be sufficiently and suitably supplied at home.  If imports were necessary they should be confined to raw materials that could be finished off in England before being re-exported.

Jean-Baptise Colbert was the Minster of Finances of France from 1665-1683 for Louis XIV.  He brought mercantilist practices to France.  Under his ministry there were widespread measures to limit imports and to favour exports.  Guilds were established, creating monopolies and thousands of foreign artisans and craftsmen were imported to establish technical learning centres that could produce goods to compete with foreign imports.

Britain also made efforts to protect and control its merchant navy and to make best use of its expanding colonies in North America.  The Navigation Acts banned the use of non-British merchant-ships to trade with its colonies and forced its colonies to only produce raw materials for and only to trade with Britain.  The diaries of George Washington and Thomas Jefferson are filled with complaints about the middlemen that they used to buy manufactured goods from Britain.  Goods which would frequently arrive broken or were sold at extortionate prices.

On the back of these policies one thing was clear: the countries that adopted flexible mercantilist practices, such as Britain and France, became wealthier and more powerful than their neighbours that did not.

Adam Smith, David Ricardo and the switch to Free Trade

The fundamental problem with mercantilism is that it is only really effective if you use it and your competitors do not.  If all countries were to adopt mercantilist practices there would be almost no trade at all.  Countries would cease to buy goods from each other and would just buy the occasional raw material that they desperately needed, and nothing else.  By the late 1700s this practice was indeed becoming the case, and even loyal colonies were beginning to get frustrated by the fact that they were not allowed to manufacture anything or to develop their own industry.  This disaffection, plus the fact that Britain refused to allow the American colonies to expand westwards after the French-Indian Wars, became one of the main drivers for the American Revolution.

Adam Smith was particularly against mercantilism and felt that it was a means by which those who had obtained monopolies could exploit consumers.  Which was exactly what they were doing.  But it was David Ricardo who managed to identify a plausible alternative to mercantilism that would solve the issue of what to do if everybody was using mercantilist practices.

He came up with the concept of comparative advantage: if one country (he used Portugal and England in his examples) is comparatively better at producing wine (e.g. higher quality for lower cost) but not as good at producing cloth (e.g. lower quality at higher cost) while another country is better at producing cloth but worse at producing wine then they would both be better off trading than doing it themselves.

At first glance Ricardian economics makes a great deal of common sense.  It also had the advantage that Britain was entering the Industrial Revolution in 1817 when Ricardo, who was one of 17 children, was writing his Principles of Political Economy and Taxation.  With the backing of this intellectual framework Britain could legitimately tell other countries that they were better off abandoning mercantilism and opening up to free trade.

So while other countries were clinging to mercantilism, Britain pushed hard for open, free, markets. It was still difficult for other countries to trade with Britain’s remaining colonies, but Britain was keen to ensure that everyone else benefited from its modern economic theories:  in 1839 Britain started to attack Chinese shipping and ports in the opening salvoes of the First Opium War to forcibly China to open up to free trade.

The problem for other countries was that as Britain had had the Industrial Revolution first. It was the first country in the history of mankind to fully decouple human labour from production.  Historically the size of a country's population was the main determinant of economic success.  The more people you had in the workforce the more things you could produce.  That is why China had been so wealthy.  Coal based steam engines powering huge factories enabled British workers to multiply their productivity so that Britain would become the manufacturing base of the entire world.

Ricardian theory, as a result, was only vaguely applicable to Britain's circumstances.  Britain could produce nearly ALL manufactured goods at higher quality and lower cost than all other nations.  All that Britain needed was raw materials and most of those could be found in its own colonies.

The American School

While Britain was merrily dumping its high quality, low cost, products across the world, devastating the economies of its forced trading partners at the same time, the US was having none of it.  Alexander Hamilton, the First US Treasury Secretary, argued that the US could not be truly independent until it became self-sufficient.  To ensure that independence happened a rival  American School of economic thought was established to counteract the British School advocated by Adam Smith, which lasted, in various guises, all the way to the 1970s.

The American School had a number of ideas. At its core was the belief that the US government should protect its industry, especially infant industries, from facing competition from abroad.  The Morrill Tariff, introduced in 1861, for example, slapped high import duties on British iron, clothing and manufactured exports.

High tariff policies lasted until the 1913 Revenue Act allowed for a federal income tax and reduced the need for import tariffs as a means of gaining revenues.  The US was also more developed economically by that time and so was better able to compete head to head with British and European manufactured products. Unlike Britain, which had relatively few raw materials and so needed its colonies, the US was well endowed with natural resources and so could produce both raw materials and manufactured goods comparatively cheaper than other nations.

Like Britain, once ready, the US was keen to take advantage of its comparative advantage in everything and to open up the world to the benefits of its free trade.  In July 1853 the US Commodore Perry sailed into Edo Bay, Japan, with his squadron of hybrid sailing  /side wheel steam frigates. He presented his demands that Japan open up, or else face the destruction wrought on China.

Japan did open up, and in turn developed its own mercantilist policies that enabled it to be militarily powerful enough to invade Korea, China and eventually attack the US navy base in Hawaii in 1941.

A quick recap

We have covered a lot of ground in this chapter, over 500 years of history, the geopolitical challenges throughout that period and the economic theories that drove change.  This background is necessary as we reach our conclusion, and many readers will already know where we are heading.

But first, a quick recap.

The dominant Western economic ideology since 19?81 has been that free trade is good, without exception.  The “proof” that this is true was the “fact” that the West won the Cold War, whilst pursuing free trade, and Communist Russia had lost.  Further evidence supporting this theory is that for the ten years after the collapse of the Soviet Union, markets liberalised everywhere and the West became richer and more powerful.

History Future Now argues, however, that the logic that “free trade is good because the West won the Cold War as a result of its adherence to free trade” is circular, and wrong.

Instead, we look at the rise of mercantilism from 1453 which turned trading prowess into political and military might.  It shows that the most successful mercantile countries such as Britain, the US and Japan, were advocates of mercantilism until they had industrialised sufficiently to give them a comparative advantage in nearly all economic activities.  Once powerful nations had reached this level of development they became keen proponents of free trade, as their businesses were able to crush all opposition.

2001- a pivotal year

Like in 1991, with the fall of the Soviet Union, 2001 was a pivotal year in history.

Two events occurred that were of note: first was the audacious Islamic attack on the World Trade Center’s two towers in September.  An act of terrorism which exposed the vulnerability of America’s open society and shocked Americas into the realisation that many foreigners really hated America.  This one violent act would lead the US and the West down a rabbit warren of costly and distracting wars in Iraq, Afghanistan and Libya, and lead to general chaos in the Muslim world, stretching from Algeria in the west to Pakistan and Indonesia in the east.

But it was three months later, on the 11th December that the most important event occurred.  After 15 years of negotiations China became a member of the World Trade Organisation.

To understand why this was such an important event we need to go back forty years, to the early 1970s and the drive for economic and financial deregulation.

Hayek, Friedman, von Miese and the push for deregulation.

During the late 1800s and early 1900s private companies delivering “utility” type services had persuaded the US government to restrict new entrants to compete across a range of sectors including water, electricity, communications and transport.  The argument was that these “public” services were expensive to provide and so companies providing these services needed regulations to protect their investments:  if there was no protection, private companies would not be able to offer customers the best possible service.  The financial services sector had also been heavily regulated in the early 1930s to help prevent the occurrence of another Wall Street crash, with the Glass-Steagall Act of 1933 and the Securities Exchange act of 1934.

But by the 1970s economists such as Hayek, Friedman and von Miese began to persuade the US government that many regulations were excessive and were stifling the economy.  In many respects this was true: laws and policies that had been enacted to stop abuses of the individual against the common good had been expanded and amended to such a level that their original purpose had been forgotten and all that remained was a morass of regulations that benefited few and stifled legitimate business.

The first major push for deregulation occurred under the Nixon administration to deregulate rail and truck transportation.  President Carter also pushed for deregulation with the 1978 Airline Deregulation Act and two other road and rail acts in 1980.  The aim for most of these deregulations was to reduce barriers to entry and to promote more independent players and competitive pricing.  Reagan continued with these policies in his first term and also promoted deregulation of the energy and telecommunications sector.

This bi-partisan push for deregulation of the US economy made a huge amount of sense. It allowed businesses operating in the US market to operate on a more level playing field and to reduced the ability for incumbents to indulge in what they referred to as “rent – seeking” activities, a real no-no for free market thinkers from Adam Smith to Milton Friedman.

And this is the key point: deregulation and freedom of competition within countries or even a number of countries that all operate on a similar basis is good for incumbents, new entrants and consumers.  Competition is on a level playing field under identical labour and environmental laws and with access to the same type of workers at similar salaries.

But the subsequent form of deregulation, that of the financial sector, was different to all previous forms of deregulation and had global implications.

Financial services deregulation

In October 1986 a new wave of deregulation took place in the financial services sector in the United Kingdom, dubbed the “Big Bang”.  The rationale behind Big Bang was that London’s place as a financial center had been undermined by competition from New York. The London banking sector was deemed as over-regulated and dominated by a cosy wine-at-lunch, old-school-tie network of public school boys.  Which was true.

One of the reasons for the 1929 Wall Street crash was that banks had used deposits from retail customers to speculate on the stock market.  A solution to this was the Glass-Steagall Act of 1932 which forcibly separated retail banks (where individuals deposited their money) from speculative investment banks.

There was no equivalent Glass-Steagall Act in the UK and merchant banks (as investment banks were called) remained as partnerships, with partners in the banks being personally liable for any of the losses incurred by their firms.  This reduced UK merchant bank’s appetites to do anything that would risk wiping out their partners financially.

What was unforeseen by Nigel Lawson, the Chancellor of the Exchequer under Thatcher, was that US financial institutions would be able to use London as a springboard to get round Glass-Steagall, enabling a new merger of retail and investment banks. By 1999 the US repealed parts of Glass-Steagall in retaliation and allowed for the merger of retail and investment banks once again.  (Author’s note – I worked for Citibank, a retail bank, at the time and was there during the merger with Salomon Smith Barney, a investment bank, a merger that formed Citigroup).

Financial services deregulation had a huge and permanent impact over the rest of the economy.  Once the deal making and innovation of investment banks became merged with the huge financial power of retail banks, investment bankers could speculate on a level not seen since the 1920s.  One practice that emerged was a drive for companies to pile on huge levels of debt, money which could be used to pay dividends, buy back shares or for management teams to buy their companies and to take them private.

To monitor the performance of these companies a new army of financial analysts emerged, hired from the top universities.  They became increasingly demanding and wanted corporate management teams to provide semi annual and then quarterly projections of their income and cash flow statements and their balance sheets.  Because investment banks took a small cut of the huge money flows that exchanged hands in these transactions they could pay their employees salaries that were higher than the best paid CEOs of large corporations.  Smart graduates with engineering, maths and physics backgrounds, who had historically gone into industry were snapped up by investment banks and their hedge fund cousins.

The pre-eminence of the financial sector fundamentally changed the relationship between capital and corporations.  Historically, wealth could only be made by investing in well-run businesses or in growing markets.  With the advent of financial deregulation investors could take poorly performing companies, asset strip them or leverage them up with debt.  The share prices of conservatively run companies stagnated compared to companies that were willing to take on higher levels of debt or to do things that made their quarterly financial results look good, whilst undermining the long term viability and profitability of their company.

During the 1990s capital from the West, managed by western investment banks, started to flow outside the West and into emerging markets as investors looked for a way to make a higher return than they could at home.  The US victory over the Soviet Union in 1991 made the US and Western model highly attractive to Third World countries, which were renamed “Developing countries”.  Waves of Western cash flooded into Asia and created speculative bubbles there, which helped to cause the 1997 Asian Financial Crisis that started in Thailand and then spread to Indonesia, South Korea, Malaysia and the Philippines.

In the US itself, investment banks and analysts looked for new ways of creating wealth and pumped resources into the newly emerging internet sector, which promised to up-end all industries.  Companies with zero revenues but with lots of “eyeballs” were listed on NASDAQ and their founders became overnight millionaires or billionaires.  (Author’s note: I had an internet company at the time and remember puzzling over how I was going to divide up my hundreds of millions of dollars between my co-founders.  They were crazy times.)  The Internet bubble burst in the spring of 2000.

Pulling everything together

So by the time China joined the World Trade Organisation in 2001 a perfect storm was beginning to gather that would destroy Western hegemony. Lets pull all the strands of this article together:

- Western success over the Soviet Union meant that the West pursued an aggressive free-market policy around the world.  As discussed earlier, this made more sense than the West’s original mercantilist policy as the West believed it would always beat foreign competitors in a free trade contest.

Western success over the Soviet Union meant that the West pursued an aggressive free-market policy around the world.  As discussed earlier, this made more sense than the West’s original mercantilist policy as the West believed it would always beat foreign competitors in a free trade contest.

- Financial services deregulation fundamentally altered the relationship between senior management teams, their shareholders and their companies.  Eager to make as much money as those in the financial services sector, management teams were incentivised to trade long term corporate performance for short-term gain, at the expense of long-term shareholders and to the demise of their own companies.

Financial services deregulation fundamentally altered the relationship between senior management teams, their shareholders and their companies.  Eager to make as much money as those in the financial services sector, management teams were incentivised to trade long term corporate performance for short-term gain, at the expense of long-term shareholders and to the demise of their own companies.

- China’s ascension to the World Trade Organisation enabled Western companies to trade with China on a scale that had hereto been impossible.  Western companies set up manufacturing hubs in China to then sell goods back to the West.  China offered aggressive incentives to Western companies, including tax free zones, assistance in recruiting millions of workers and minimal labour and environmental protection laws.

China’s ascension to the World Trade Organisation enabled Western companies to trade with China on a scale that had hereto been impossible.  Western companies set up manufacturing hubs in China to then sell goods back to the West.  China offered aggressive incentives to Western companies, including tax free zones, assistance in recruiting millions of workers and minimal labour and environmental protection laws.

- Low cost goods from China, and then other countries who jumped on the bandwagon, allowed for materially higher standards of living in the East without causing inflation in the West.  After the high inflationary period of the 1970s the West was particularly frightened of inflation: they had seen the consequences of runaway inflation in Germany and Austria during the 1930s.

Low cost goods from China, and then other countries who jumped on the bandwagon, allowed for materially higher standards of living in the East without causing inflation in the West.  After the high inflationary period of the 1970s the West was particularly frightened of inflation: they had seen the consequences of runaway inflation in Germany and Austria during the 1930s.

- China was very aware of how the West had become so dominant since the 1450s and itself pursued a similar mercantilist trading philosophy.  This disparity amounted to asymmetric warfare as the West’s markets remained open to free trade whilst China discouraged domestic consumption.  China focused on obtaining raw materials to then convert into manufactured products that were sold in exchange for US dollars, Euros and Sterling resulting.  This policy led to a huge trade surplus and a massively high level of foreign reserves.

China was very aware of how the West had become so dominant since the 1450s and itself pursued a similar mercantilist trading philosophy.  This disparity amounted to asymmetric warfare as the West’s markets remained open to free trade whilst China discouraged domestic consumption.  China focused on obtaining raw materials to then convert into manufactured products that were sold in exchange for US dollars, Euros and Sterling resulting.  This policy led to a huge trade surplus and a massively high level of foreign reserves.

- China then recycled these foreign reserves back into the West by buying predominantly US government debt.  Since the trade surplus was so large it meant that China quickly became one of the largest holders of US Treasury Bills, which made it easy for the US Treasury to issue government debt with low interest rates.  It is for this reason that interest rates during the 2000s were so low for many Western countries.

China then recycled these foreign reserves back into the West by buying predominantly US government debt.  Since the trade surplus was so large it meant that China quickly became one of the largest holders of US Treasury Bills, which made it easy for the US Treasury to issue government debt with low interest rates.  It is for this reason that interest rates during the 2000s were so low for many Western countries.

- Since interest rates were so low, the deregulated financial sector encouraged consumers in the West to take on increasingly large levels of debt for personal consumption. This resultant credit boom drove demand for low cost Chinese products resulting in higher Chinese trade surpluses, resulting in more purchases of Western debt, resulting in lower interest rates, driving more debt for more consumption

Since interest rates were so low, the deregulated financial sector encouraged consumers in the West to take on increasingly large levels of debt for personal consumption. This resultant credit boom drove demand for low cost Chinese products resulting in higher Chinese trade surpluses, resulting in more purchases of Western debt, resulting in lower interest rates, driving more debt for more consumption

- In addition, since interest rates were so low this encouraged a boom in the housing market.  This meant that house prices went up significantly higher than inflation (which was kept artificially low by low cost goods from developing countries) which meant that people felt wealthier than they had previously.  Many re-mortagaged their homes and took out equity in the form of cash which they then used to fund home extensions and renovations, purchase holidays, new cars and other items which further enhanced the supply of money in Western economies. Much of this money went to purchase goods made in China, further increasing China’s foreign reserves.

In addition, since interest rates were so low this encouraged a boom in the housing market.  This meant that house prices went up significantly higher than inflation (which was kept artificially low by low cost goods from developing countries) which meant that people felt wealthier than they had previously.  Many re-mortagaged their homes and took out equity in the form of cash which they then used to fund home extensions and renovations, purchase holidays, new cars and other items which further enhanced the supply of money in Western economies. Much of this money went to purchase goods made in China, further increasing China’s foreign reserves.

- As more people were able to purchase homes, house prices kept going up. Investment banks encouraged their retail arms to lend money to poor people who would have been shunned as bad credits by traditional savings and loans banks (building societies in the UK).  In the event that the customer was unable to repay their mortgage or make their interest payments, since property prices were going up investors believed that they were reasonably secure.  To enhance the creditworthiness of these assets investment banks packaged thousands of these sub-prime loans with higher quality loans on the assumption that even if a few people went into default the risks would be spread out over millions of good quality loans.  This did not quite work as planned and resulted in the 2007 financial crash which kicked off the Great Recession.

As more people were able to purchase homes, house prices kept going up. Investment banks encouraged their retail arms to lend money to poor people who would have been shunned as bad credits by traditional savings and loans banks (building societies in the UK).  In the event that the customer was unable to repay their mortgage or make their interest payments, since property prices were going up investors believed that they were reasonably secure.  To enhance the creditworthiness of these assets investment banks packaged thousands of these sub-prime loans with higher quality loans on the assumption that even if a few people went into default the risks would be spread out over millions of good quality loans.  This did not quite work as planned and resulted in the 2007 financial crash which kicked off the Great Recession.

- As more companies set up manufacturing centers in low cost countries such as China and other parts of South East Asia, it became increasingly difficult for Western companies to compete without following suit by also taking advantage of low cost labour and weak labour and environmental laws.  Stock market analysts punished companies that did not have the ability to outsource more of their manufacturing, pushing their share prices lower.  New management teams were then hired who pursued a more aggressive outsourcing model.

As more companies set up manufacturing centers in low cost countries such as China and other parts of South East Asia, it became increasingly difficult for Western companies to compete without following suit by also taking advantage of low cost labour and weak labour and environmental laws.  Stock market analysts punished companies that did not have the ability to outsource more of their manufacturing, pushing their share prices lower.  New management teams were then hired who pursued a more aggressive outsourcing model.

- As the Chinese economy grew, due to Western investment, China was able to strike increasingly hard bargains with Western companies eager to access the Chinese market.  This included a requirement to set up joint ventures with Chinese state owned companies and to transfer critical technology and know how.  This strategy has enabled China to rapidly move up the value chain since 2001, moving from the manufacture of cheap clothes and toys to making sophisticated wide bodied passenger planes to compete with Boeing and Airbus and high speed rail trains to compete with Alstom, Hitachi and Siemens.  A similar transformation has occurred in the services sector in India, which has dominated the offshoring of back-office functions of law firms, accountants and big retail and investment banks.

As the Chinese economy grew, due to Western investment, China was able to strike increasingly hard bargains with Western companies eager to access the Chinese market.  This included a requirement to set up joint ventures with Chinese state owned companies and to transfer critical technology and know how.  This strategy has enabled China to rapidly move up the value chain since 2001, moving from the manufacture of cheap clothes and toys to making sophisticated wide bodied passenger planes to compete with Boeing and Airbus and high speed rail trains to compete with Alstom, Hitachi and Siemens.  A similar transformation has occurred in the services sector in India, which has dominated the offshoring of back-office functions of law firms, accountants and big retail and investment banks.

- The consequent loss of jobs and good jobs is starting to cause a breakdown in Western societies.  Unemployment rates of over 50% for young people in parts of Europe will cause devastation for that entire generation.  They will have lower incomes; will pay lower amounts of tax, which will impact pensions for the elderly and the ability to pay for services for themselves and for younger generations.  Society will be split and those that have jobs will start to resent those that have no jobs and those with no jobs will look upon those with jobs with envy.

The consequent loss of jobs and good jobs is starting to cause a breakdown in Western societies.  Unemployment rates of over 50% for young people in parts of Europe will cause devastation for that entire generation.  They will have lower incomes; will pay lower amounts of tax, which will impact pensions for the elderly and the ability to pay for services for themselves and for younger generations.  Society will be split and those that have jobs will start to resent those that have no jobs and those with no jobs will look upon those with jobs with envy.

- Meanwhile, the West’s wars with Islamic countries distracted the attention of politicians and the general public from what was going on with their economies.

Meanwhile, the West’s wars with Islamic countries distracted the attention of politicians and the general public from what was going on with their economies.

These are the reasons why the West finds itself in great difficulty.  Like Dr Faustus, who traded his soul to the devil for greater knowledge, the West traded away its Ricardian comparative advantages in a wide range of manufacturing and service sector roles; advantages built up over a century of accumulated intellectual know-how, in exchange for about eight years of unparalleled economic growth and prosperity that were fundamentally destructive to their economies.

So what does this mean for the future?

Dr Faustus begged the devil and God to have mercy on his soul and to release him from his agreement.  What about the West?  If we could go back in time or change our ways in the future what should we do?  Future History Now offers two key possibilities.

First, there must be an understanding that the West’s development and wealth originally derived from mercantilism, not from free trade.  Free trade only became desirable once the West was sufficiently advantaged compared to its likely competitors that it could compete freely, and guarantee that it would win every time.

The West must also accept that China is pursuing the same mercantilist practices that made the West successful.  China is totally within its right to do this, and the practice makes sense for the Chinese government on behalf of its population.  But in an asymmetric battle between one country pursuing a mercantilist policy and another country pursuing an open market and free trade policy, the mercantilist country should win out.

Since the US cannot control what China does, and can only control US policy, the US and the West should respond with mercantilist policies of its own.  This means shutting down Chinese imports of goods that could be made in the West until both parties can really operate on a level playing field – which includes wage and labour costs as well as environmental law parity.

Second, parts of the financial services sector have become dangerous for the overall health of the West’s economy and society for a number of reasons, and need to be reformed.

On the consumer side, banks have enabled individual citizens to borrow funds on a level that is excessive.  This has allowed individuals to feel wealthier than they really are, a nice feeling while it lasts, but ultimately leading to home foreclosures and personal bankruptcy.  The excessive lending of money to the housing market has diverted capital from productive activities, such as investment into small businesses, into creating an inflationary bubble in the housing market, a sector with no intrinsic value other than as somewhere to live.

On the corporate side, banks have forced company management teams to act in the short-term interests of financial sector intermediaries, who make money whether share prices go up or down, instead of in the interests of their long term shareholders, employees and customers.  These practices have  included taking on high levels of corporate debt and outsourcing core parts of their business, including technical know-how, to future competitors.

The financial services sector is also taking too many of the best and brightest from our top universities.  Top Western graduates are making a rational decision: why work hard as an engineer in a declining manufacturing company with low status and low pay when you can earn a fortune by skimming a small percentage off the huge financial flows of companies all over the world.

Many parts of financial sector deregulation have resulted in great benefits to society and the economy.  Unpicking the good parts from the bad will be no easy task.

There is hope

While the West may be in trouble today it is not impossible to imagine a move by Western governments to restrict trade with China and other countries that are aggressively mercantilist.  Equally, financial sector reform to fix the worst excesses, despite the powerful lobbying efforts from the financial sector, is not impossible either.

But few politicians are leaders. To lead requires going out ahead of the crowd, not knowing whether anybody else is following.  This is frightening for modern career politicians: going too far from the crowd could mean the end of your political career.  Instead most politicians act as mirrors, using polls to reflect back from the public what the public wants to see and believe.

But most people are too busy with their normal lives to understand everything that is needed for good governance.  They have jobs, families, children, hobbies and concerns that fully occupy their time.  To expect them to have a full understanding of historical precedent, monetary policy, foreign affairs and so forth is unfair and unrealistic.

That is why we have a representative democracy. Our politicians are elected to represent the people.  Their job is to understand these issues and to use their judgement to push for policies that are for the benefit of the people that they were elected to represent.

History Future Now has a large following of politicians and members of the military.  So this is a message to you: this article is a relatively short synthesis of a huge number of interconnecting problems.  Read it, think about it and forward it to your colleagues.

And then lead! Lead from the front and call for reforms of our trade policy. Call for reforms of our financial sector.

Our entire way of life hangs in the balance.

You may be our only hope.

## The North African Threat And Mediterranean Reunification

## The Rise Of The West Was Based On Luck. That Has Run Out.

---

## THEN: 

## NOW: 

## NEXT: 

