---
title: 'The immorality of climate change, a reflection on slavery and the Civil War'
url: >-
  https://www.historyfuturenow.com/part-1-natural-resources/the-immorality-of-climate-change-a-reflection-on-slavery-and-the-civil-war
image: "/images/climate-slavery-moral.png"
type: article
part: Natural Resources
slug: the-immorality-of-climate-change-a-reflection-on-slavery-and-the-civil-war
excerpt: >-
  Today, few people look back upon African slavery in the Americas as a good
  thing. There are no rousing speeches defending slave owners rights over their
  property, or demands not just to maintain the institution of slavery within
  their own borders but also to expand slavery into neighbouring states. There
  are no armies of poor white men fighting to keep rich white men's dominion
  over black slaves in the hope that one day, they too might become rich white
  men lording it over their own field and house negroes. And yet a mere 150
  years ago, in the United States, this morality existed and a great Civil War
  took place between the Northern and the Southern states. 150 years is not a
  long time. Photography, telegraphs, railroads and huge factories existed. Many
  of your grand or great grand parents would have been alive.
signal: ''
---
# The immorality of climate change, a reflection on slavery and the Civil War

Today, few people look back upon African slavery in the Americas as a good thing.  There are no rousing speeches defending slave owners rights over their property, or demands not just to maintain the institution of slavery within their own borders but also to expand slavery into neighbouring states.  There are no armies of poor white men fighting to keep rich white men's dominion over black slaves in the hope that one day, they too might become rich white men lording it over their own field and house negroes.  And yet a mere 150 years ago, in the United States, this morality existed and a great Civil War took place between the Northern and the Southern states.  150 years is not a long time. Photography, telegraphs, railroads and huge factories existed.  Many of your grand or great grand parents would have been alive.

The people who lived then were recognisably like ourselves, and yet millions of them did look upon African slavery as a good thing, and did fight to maintain it.  This raises two interesting questions.  First, how did their sense of morality allow them to think this way and second, if we project ourselves 150 years into the future will our grand and great grand children look back at the way we live in a similar mixture of fascination and horror?  Will our management of the environment, global warming, fisheries collapse, species extinctions be equally vilified? African slavery grew gradually but by 1831 there was a widespread belief that the institution would die off as both the British Parliament and the US Congress abolished the international slave trade. With no ability to buy and then trade slaves from the west African coast, the theory went that eventually the slaves that were in circulation would literally die off, leaving even the Southern states slave free.  This view became increasingly tenuous as slave owners discovered the financial joys of breeding their own slaves, for personal use and for sale within the southern states, and the rise of the cotton industry in the 1840-1850s.  Cotton had previously been difficult to process, but new cotton gins, machinery that allowed the fluffy white part to be separated from its harder skin, meant that cotton rapidly became a cash crop, making planters in the South, where cotton was most viable, incredibly wealthy.

In the North, this renewed Southern enthusiasm for slavery clashed with their sense of morality.  Why was the United States, the icon of freedom and liberty who had inspired the French revolution and the 1848 revolutions across Europe, the only major country to continue to have slavery?  With no suitable land for cotton and no embedded plantation class, the North saw the sins of slavery and did not enjoy the economic benefits.  In the South, the economic benefits trumped any moral qualms that they may have had.  Getting rid of slavery in the United States, however, was no easy task.  By 1847 there were 15 slave and 14 free states.  The North had the majority of the population and thus greater control over Congress, but each state had only two senators, effectively allowing the slave states to block any anti slavery legislation.

But the North had a trump card: expansion of the number of states.  Following the 1836 Texas declaration of independence from Mexico and the 1846 -7 Mexican war with the United States, a whole number of new states could be created. If those states were free states, the balance of power in the Senate would swing away from the South, making it more likely that both Congress and the Senate would pass bills banning slavery.  With the victory of Lincoln and the Republicans in 1860, on an anti slavery platform, the writing was on the wall.  Preemptively, before Lincoln had even been inaugurated, many of the Southern states seceded from the Union, setting the stage for the American Civil War.

The struggle over slavery had become a struggle over the way of life for people in the South.  And yet, very few of the 5 million whites in the South were large slave owners: 48,000 had more than 20 slaves.  Very large slave owners numbered in the hundreds and were the richest and most politically powerful men in their communities. Defence of slavery became synonymous with a defence of Southern life and values.  Morality was completely thrown out of the window and the more the North looked as though it was going to win the battle for black slaves the more the South reacted against it.

Today, we live in a world that still abounds with morally suspect choices.  We still do things that we know are damaging for us all.  We destroy habitats, rain forests, kill dolphins, whales, great apes, tigers and other endangered species. The science about climate change is unambiguous: the planet is getting hotter and mankind is the cause.  Fisheries are on the verge of collapse around the world.  And yet there are a vocal number of people who stand up against the onslaught of history and push for more oil, gas and coal and push back against renewables.  There are people who push for more subsidies for large factory fishing vessels and even higher quotas for catches.  Like the Southern States there are rich, powerful vested interests who want to maintain the status quo and like the Southern States there are millions of poor who support and identify with their cause, despite gaining no financial benefit.

This struggle between economically vested interests pursuing morally dubious choices does not have to end, like the United States, in conflict.  The Civil War also showed us that people can go directly against their economic interest if they can be persuaded to put morality first.  The Confederate South believed from the outset that Great Britain would support them in the war: it was British cotton mills that purchased the bulk of the 4 million bales of cotton that the South produced every year.  They calculated that it would be disastrous for the mill owners if they could not get the raw ingredients to feed their mills.

They were wrong. The anti slavery movement was so strong that Britain turned its back on Southern cotton. Some mills did do badly, others found alternative sources.

They adjusted, and so should we

## The renewables and battery revolution. What history teaches us about the future.

---

## THEN: 

## NOW: 

## NEXT: 

