---
title: Why Do We Need The Military? Securing Energy Supplies And Trade Routes
url: >-
  https://www.historyfuturenow.com/part-2-global-balance-of-power/why-do-we-need-the-military-securing-energy-supplies-and-trade-routes
image: "/images/military-energy-trade.png"
type: article
part: Global Balance of Power
slug: why-do-we-need-the-military-securing-energy-supplies-and-trade-routes
excerpt: >-
  History Future Now examines our military expenditure and asks two basic
  questions: first, what is the purpose of the military? And second, if we did
  things differently would we need to spend so much on the military? The results
  were surprising and the conclusion is clear: the military is no longer used to
  defend our borders and countries from attack, but to maintain secure energy
  supplies and trade routes. Both of which are not worth fighting for. Read on
  to discover the astounding statistics to show why.
signal: ''
---
# Why Do We Need The Military? Securing Energy Supplies And Trade Routes

History Future Now examines our military expenditure and asks two basic questions:  first, what is the purpose of the military? And second, if we did things differently would we need to spend so much on the military?  The results were surprising and the conclusion is clear: the military is no longer used to defend our borders and countries from attack, but to maintain secure energy supplies and trade routes.  Both of which are not worth fighting for.  Read on to discover the astounding statistics to show why.

Protecting our nation against invasion and attack

Historically the purpose of the military has been to defend our nation’s borders against invasion and external attack.  And yet if you look at our most recent military encounters in Afghanistan, Iraq and Libya it is clear that our military was not used for this purpose. None of those countries were about to invade our nation’s borders.

The wars in Iraq and Afghanistan were arguably about defending our nations against external attack.  The invasion of Afghanistan was based on the fact that its government had aided and abetted a terrorist group that had attacked the United States. Afghans refused to hand over members of Al Quaida and so the invasion was justified in hunting down Al Quaida extremists.  In theory, once the Al Qaida members had been killed or captured, the military requirement would disappear.

The invasion of Iraq was based on evidence, eventually discovered to be false, that Iraq had both the capacity and intent to strike out against the West.  After refusing to hand over the weapons of mass destruction that he did not possess Saddam Hussain found himself in the crosshairs of one of the most sophisticated military operations in history.  In theory, once this threat had been eliminated, the military requirement of being in Iraq would disappear.

The attacks on Libya fail both of these premises.   Colonel Gaddafi posed no threat of invasion to any country and he was not threatening to attack any country either.  In fact Colonel Gaddafi had recently received a visit from the then UK Prime Minster Blair in the hope of securing oil contracts for British companies.

Unfortunately, the aftermath of Western attacks on Iraq, Afghanistan and Libya has been chaos.  None of the three countries is expected to be able to invade any country any time soon.  None of those countries are expected to attack or launch attacks on our country any time soon either.  Arguably, the chaos created is so great that these countries could spawn extremist groups that would launch terrorist attacks on the countries that had just invaded them.  At the moment, however, they seem to be content to kill their compatriots of other ethnic and religious persuasions or the foreign military forces that remain.

So the answer to the first question appears to be more complex than merely defending our nation’s borders against invasion and external attack.

Do we do it for humanitarian reasons?

Western intervention in Libya has been put down to humanitarian needs.  But then there are many parts of the world, in particular Africa, that are embroiled in civil wars at this moment in time.  There are humanitarian needs in these places but no Western boots on the ground.  Syria is going through a civil war that is almost identical to that which occurred in Libya, but the West has banned large arms sales to rebels there.  We have not even bombed Syrian government forces.  By a similar stage in the conflict in Libya we were attacking Gaddafi forces daily.

So humanitarian reasons are not valid uses of military power, otherwise we would be invading countries all of the time.

Is it all about energy security?

One frequent accusation from people of a left leaning political persuasion is that it is all about oil.  Attacking Iraq was all about securing oil supplies.  Libya is also a large oil producer and so once the civil war had started the West thought that it would be best to finish on the side of the victors.  Since it is very hard to prop up a failing, unpopular regime, it made more sense to blow it up and join the victory parade with the rebels.  This would explain why we are not intervening in Syria and parts of Africa.  They have no oil and so it is not worthwhile.

Whilst this makes for a great conspiracy theory – a grab for oil – the reality is far less exciting but significantly more illogical.  Have a look at the 2011 imports of oil table below in thousands of barrels of oil per day to the United States, according to the US Energy Information Administration.

Firstly, most oil that the US consumes comes from the United States itself. Of the imports, the bulk comes from the Western Hemisphere: Canada (26%), Mexico (7%), Venezuela (10%), Colombia (4%), US Virgin Islands (2%), Ecuador, (2%), Brazil (1%), Aruba (1%) and Trinidad and Tobago (1%).  A chunk comes from sub Saharan Africa with Nigeria (9%) as the biggest player.   The Middle East and North Africa do provide a good slice, but it is dominated by Saudi Arabia (13%), Iraq (5%), Algeria (4%) and Kuwait (2%). Libya clearly used to export more oil to the US, but not a huge amount – in 2007 it exported the equivalent of Trinidad and Tobago in 2011.

If the US were to suddenly stop all imports from countries that sponsor terrorism that attack the United States, such as from Saudi Arabia, who is frequently referred to as the cash machine of Wahhabi Islam, the impact on US imports would be relatively minor.  Other countries could fill in the gap.  And this is where things get interesting.  In another Chapter (P_) History Future Now observed that:

The military cost of supporting cheap oil, however, is even more extraordinary.  According to another survey, the cost of the US maintaining its fleet in the Persian Gulf (explicitly to defend oil shipping lanes) was $7,300 billion between 1976 and 2007 – or £235 billion on average per year.   The direct US cost of the war in Iraq and Afghanistan (excluding the First Gulf War) between 2001 and 2010 is estimated to be $2.6 trillion (or $300 billion per year) and could go as high as $4.4 trillion.

So given the fact that it costs the US between $535,000,000,000 per year to maintain its fleet and troops in Iraq and Afghanistan, and that the US imports a total of 1,843,000 barrels per day from Saudi Arabia, Kuwait and Iraq or 672,695,000 barrels per year.  The cost is equivalent to a subsidy of $795 per barrel of oil.  So while it may cost a little more than $2 per barrel to pump oil out of the ground in Saudi Arabia and can be sold at $92 per barrel, providing the Saudis with a profit of $90 per barrel, it costs the US taxpayer an additional $349 per barrel to maintain the US Persian fleet during a normal year and a whopping $795 per barrel when you include the cost of wars in Iraq and Afghanistan.

So for the US, the marginal cost of Persian Gulf oil is between $441 and $887 per barrel.  If it could find oil for less than that, it would be better off.  And it can.  Based on these numbers, the 24% of oil that the US imports from Saudi Arabia, Kuwait, Iraq and Algeria, costs 2.63 times more than ALL of the other oil it imports from the rest of the world combined.

Given the cost of the US’s involvement in the Middle East, we would have to add energy security to the reasons why the US maintains a large military budget.  This reason brings the total rationale for maintaining a military to three: preventing an invasion, defending against attack and maintaining energy supply security.  It is worth observing that the final aim is ironic. It is the US’s maintenance of security in the Middle East that makes the Muslim world perceive it as an aggressive power, which makes them more likely to want to attack the West, which makes the cost of securing supply even higher.

Is it about protecting and enhancing free movement of trade?

But if you look at the US defense budget, it becomes clear that securing oil supplies is not the only reason for the deployment of military forces, as the USPACOM website helpfully elaborates:

The United States Pacific Command (USPACOM) Area of Responsibility (AOR) encompasses about half the earth’s surface, stretching from the waters off the west coast of the U.S. to the western border of India, and from Antarctica to the North Pole.  The 36 nations that comprise the Asia-Pacific region are home to more than 50% of the world’s population, three thousand different languages, several of the world’s largest militaries, and five nations allied with the U.S. through mutual defense treaties. Two of the three largest economies are located in the Asia-Pacific.

U.S. military and civilian personnel assigned to USPACOM number approximately 325,000, or about one-fifth of total U.S. military strength. U.S. Pacific Fleet includes six aircraft carrier strike groups, approximately 180 ships, 1,500 aircraft and 100,000 personnel. Marine Corps Forces, Pacific possesses about two-thirds of U.S. Marine Corps combat strength, includes two Marine Expeditionary Forces and about 85,000 personnel assigned. U.S. Pacific Air Forces is comprised of approximately 40,000 airmen and more than 300 aircraft, with about 100 additional aircraft deployed to Guam. U.S. Army Pacific has more than 60,000 personnel assigned, including five Stryker brigades. Of note, component command personnel numbers include more than 1,200 Special Operations personnel. Department of Defense Civilians and Contractors in the Pacific Command AOR number about 40,000. Additionally, the U.S. Coast Guard, which frequently supports U.S. military forces in the region, has approximately 27,000 personnel in its Pacific Area.

Crudely put, “one fifth” of total US military strength is 20% of the $687,000,000,000 spent on defense in 2011, or  $137 billion, which is slightly smaller than China’s entire defense budget and more than double that of the UK’s entire defense budget for the similar period.  As you can read from the USPACOM introduction, the bulk of these forces comprise of the Navy and Marines.  Their job is to protect sea-lanes.

This raises two additional questions: Who are we protecting?  And what are we protecting them from?  Clearly, we are not protecting US territory – with the exception of Hawaii and a few Pacific islands.  There is no terrorist threat in this part of the world.  We are providing protection for our allies – Japan, Korea, Taiwan and Australia.  But against whom?  Pirates don't really warrant $137 billion of expenditure and six carrier strike groups.  The only obvious target is China, the up and coming superpower.  China is also one of US’ largest trading partners, with whom the US has run a trade deficit of $295,000,000,000 in 2011 and $273,000,000,000 in 2010.

Just to make this clear: the US spends $137 billion per year on its military in the Pacific so that it can lose $295 billion per year to China.  The US also loses $63 billion to Japan, $13 billion to Korea, $15 billion to Taiwan and $14 billion to India: a total of $400 billion per year. It actual makes money from Australia, but at $17 billion this is not enough to offset much of the loss.

As we have examined in other chapters, these trade deficits do not just represent something inconvenient, but represent the hollowing out of the economies of developed countries as jobs, skills, technology and capital are transferred on an epic scale to places like China and India.

And yet, as with securing energy supplies in the Middle East, the US and other developed countries are paying subsidies to lose these jobs.

If we did things differently would we need to spend so much on the military?

This brings us to the conclusion and to the second question that we asked at the beginning of this article:  if we did things differently would we need to spend so much on the military?

The US’s Founding Fathers hated the concept of a large standing army and viewed it as a means of oppression of the people.  They called for militias to be established that could come to the aid of the nation in the event of an invasion.  Just under 200 years later, Republican President Eisenhower, a Second World War hero, famously said the following at his Presidential farewell address in January 1961:

A vital element in keeping the peace is our military establishment. Our arms must be mighty, ready for instant action, so that no potential aggressor may be tempted to risk his own destruction…

This conjunction of an immense military establishment and a large arms industry is new in the American experience. The total influence — economic, political, even spiritual — is felt in every city, every statehouse, every office of the federal government. We recognize the imperative need for this development. Yet we must not fail to comprehend its grave implications. Our toil, resources and livelihood are all involved; so is the very structure of our society. In the councils of government, we must guard against the acquisition of unwarranted influence, whether sought or unsought, by the military-industrial complex. The potential for the disastrous rise of misplaced power exists, and will persist.

We must never let the weight of this combination endanger our liberties or democratic processes. We should take nothing for granted. Only an alert and knowledgeable citizenry can compel the proper meshing of the huge industrial and military machinery of defense with our peaceful methods and goals so that security and liberty may prosper together.

So picking up on his call for an ”alert and knowledgeable citizenry” History Future Now raises some challenges.

The first role of a government is to defend its borders and its people.  There is no doubt that that purpose is critical and Ike would agree. The Founding Fathers called for militias, though that is probably slightly anachronistic.  Whether we need to project power overseas is a different question.

Using our military to secure energy supplies is, as the statistics show, an absurd waste of money.  For the cost of maintaining the US navy in the Persian Gulf on an annual basis and throwing in the cost of the wars in Afghanistan and Iraq, the US could become completely energy independent.  It could have provided free solar panels to every US household and commercial building, created wind farms, battery storage capacity, smart grids and electric cars for all.  For that price it could have disengaged from the Middle East, reducing the friction with the Muslim world, reducing the likelihood of terrorist attacks and reduced the cash available for the funding of terrorist organisations by Saudi Arabia

Using our military to provide the safe transport of goods from China and India also makes no sense.  The military budget plus the trade deficit adds up to over $537 billion per year to this region.  Why are we paying that amount of money every year so that our economies can get hollowed out, our young people can have no jobs and our retired people lose out on their pensions?  In another chapter we discussed the establishment of trading zones for similar countries.  These zones would have free trade within and tariff barriers surrounding them. A foreign company wanting to sell manufactured goods and services within the trading zone would be free to do so – so long as you created the factory and jobs to do so within the trading zone: just like China does today. This would help stop countries from competing in a race to the bottom on wages and environmental and job protections.

If we did these things we would not need to spend so much on our military and we would have a healthier global economy at the same time.

This is a reason for optimism.

## The West’s romance with Free Trade is ending. Why?

## Why China Could Invade Taiwan – And Get Away With It

---

## THEN: 

## NOW: 

## NEXT: 

